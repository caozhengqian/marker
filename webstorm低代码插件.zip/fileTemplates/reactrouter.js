import React from 'react';
import "./index.less";
import { withRouter } from "react-router-dom";

 class ${COMPONENT_NAME} extends React.Component {
    constructor(props) {
        super(props);
        this.state = {};
    }

    componentDidMount() {

    }
    toTest=(a)=>{
        console.info(this.props)
        this.props.history.push({
            pathname: "/test",
        });
    };
    render() {
        return (
            <div className="${Class_NAME}">
                  ${COMPONENT_NAME}
                <p onClick={this.toTest.bind(this,2)}>点击跳转</p>
            </div>
        );
    }
}
export default withRouter(${COMPONENT_NAME})