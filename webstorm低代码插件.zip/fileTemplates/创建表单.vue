<template>
  <div style="margin:20px 20px 0 20px;border: 1px solid rgb(144, 147, 153);padding:20px 20px 0 20px">
    <el-form :model="formData" :rules="rules" ref="ruleForm" label-width="160px">
      <el-row >
#foreach( $ref in $CopyRule.split(",") )
    #if($ref.split("-")[1] == 'select')
        <el-col :span="6">
          <el-form-item label="$ref.split("-")[0]：" prop="$ref.split("-")[4]">
            <el-select v-model="formData.$ref.split("-")[4]" clearable style="width:100%">
              #foreach( $ref1 in $ref.split("-")[3].split("&") )
                 <el-option label="$ref1.split("@")[0]" value="$ref1.split("@")[1]"/>
              #end
            </el-select>
          </el-form-item>
        </el-col>

    #{else}
            <el-col :span="6">
          <el-form-item label="$ref.split("-")[0]：" prop="$ref.split("-")[4]">
            <el-input v-model="formData.$ref.split("-")[4]" clearable></el-input>
          </el-form-item>
        </el-col>
    #end
#end
      </el-row>
    </el-form>
  </div>
  <div class="foot">
    <el-button type="primary"
               v-loading.fullscreen.lock="loading"  
               @click.stop="submit">
               提交
    </el-button>
    <el-button  @click="closeWindow">关闭</el-button>
  </div>
</template>

<script>

export default {
  components: {
  },
  name: '${NAME}',
  computed: {
  },
  data() {
    return {
      loading:false,
      formData: {
        #foreach( $ref in $CopyRule.split(",") )
            $ref.split("-")[4]:"",//$ref.split("-")[0]
        #end
      },
      rules: {
        #foreach( $ref in $CopyRule.split(",") )
             #if($ref.split("-")[2] == 'Y')
                $ref.split("-")[4]: [{ required: true, message: '请输入$ref.split("-")[0]', trigger: 'change' } ],// $ref.split("-")[0]
             #{else}
                $ref.split("-")[4]: [{ required: false, message: '请输入$ref.split("-")[0]', trigger: 'change' } ],// $ref.split("-")[0]
             #end
        #end
      }
    }
  },

  methods: {
    closeWindow(){

    },
    submit() {
      this.loading = true
      this.$#refs['ruleForm'].validate((valid, err) => {
        if (valid) {
          let formTmp = this.formData
          let resTmp = {
           #foreach( $ref in $CopyRule.split(",") )
            $ref.split("-")[4]:formTmp.$ref.split("-")[4],//$ref.split("-")[0]
           #end
          }
          console.log(`%c ${JSON.stringify(resTmp)}`, "color:red");
          this.loading = false
        }else{
          this.loading = false
        }
      })
    }
  }
}
</script>

<style scoped>
.foot {
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-end;
  margin-top: 30px;
  box-sizing: border-box;
  padding-right: 30px;

}
.btn {
  box-sizing: border-box;
  padding: 8px 30px;
  font-size: 16px;
  font-weight: bold;
  letter-spacing: 2px;
  border-radius: 3px;
}
.submit {
  border: 1px solid #03297a;
  color: #03297a;
  background-color: #ffffff;
  margin-right: 20px;
}
.close {
  background-color: #ffffff;
  border: 1px solid #9a9a9a;
  color: #666;
}
</style>
