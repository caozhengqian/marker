<template>
    <div class='${NAME}'>
        <p>${NAME}</p>
    </div>
 
</template>

<script>
//import { mapState } from "vuex";
//import All from "./comLife/All";
export default {
    components: {
 //       All,
    },
    name: '${NAME}',
    props: {
    //  msg: String
    },
    computed: {
       // ...mapState(["activityData"])
    },
    data() {
        return {

        }
    },
    created() {

    },
    methods: {
        aa(){},
    }

}
</script>

<style lang="less" scoped>
    .${NAME}{
    
    }
</style>
