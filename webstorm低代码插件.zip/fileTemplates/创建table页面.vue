<template>
  <div style="margin:20px 20px 0 20px;border: 1px solid rgb(144, 147, 153);padding:20px 20px 0 20px">
    <el-form :model="formData" :rules="rules" ref="ruleForm" label-width="160px">
      <el-row >
#foreach( $ref in $CopyRule.split("%")[0].split(",") )
    #if($ref.split("-")[1] == 'select')
        <el-col :span="6">
          <el-form-item label="$ref.split("-")[0]：" prop="$ref.split("-")[4]">
            <el-select v-model="formData.$ref.split("-")[4]" clearable style="width:100%">
              #foreach( $ref1 in $ref.split("-")[3].split("&") )
                 <el-option label="$ref1.split("@")[0]" value="$ref1.split("@")[1]"/>
              #end
            </el-select>
          </el-form-item>
        </el-col>

    #{else}
            <el-col :span="6">
          <el-form-item label="$ref.split("-")[0]：" prop="$ref.split("-")[4]">
            <el-input v-model="formData.$ref.split("-")[4]" clearable></el-input>
          </el-form-item>
        </el-col>
    #end
#end
      </el-row>
    </el-form>
  </div>
  <div class="foot">
    <el-button type="primary"
               v-loading.fullscreen.lock="loading"  
               @click.stop="submit">
               查询
    </el-button>
    <el-button  @click="closeWindow">关闭</el-button>
  </div>
  <div class="tablemain">
    <el-table :data="tableData" style="width: 100%">
    #foreach( $ref in $CopyRule.split("%")[1].split(",") )
          <el-table-column prop="$ref.split("-")[0]" sortable label="$ref.split("-")[1]"></el-table-column>
    #end
      <el-table-column  fixed="right" label="编辑" width="260">
        <template #default="scope">
          <el-button type="primary" plain @click="edit(scope.row)">修改</el-button>
          <el-button type="primary" plain @click="detail(scope.row)">查看详情</el-button>
          <el-button type="primary" plain @click="stopButton(scope.row)">终止</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div>
      <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page= "currentPage"
          :page-sizes="[10, 25, 50,100]"
          :page-size="10"
          layout="total, sizes, prev, pager, next, jumper"
          :total="10"
      ></el-pagination>
    </div>
    <el-dialog :title="titleDia" v-model="dialogFormVisible" @close="closeDialog" style="padding-bottom:50px">
      <el-form
          :model="formData1"
          ref="ruleForm"
          label-width="160px"
          disabled
      >
        <el-row >
       #foreach( $ref in $CopyRule.split("%")[1].split(",") )
         <el-col :span="24">
            <el-form-item label="$ref.split("-")[1]：" prop="$ref.split("-")[0]">
              <el-input v-model="formData1.$ref.split("-")[0]" ></el-input>
            </el-form-item>
          </el-col>
       #end
        </el-row>
      </el-form>
      <el-button style="float:right" type="primary" @click="_s">确定</el-button>
    </el-dialog>
  </div>
</template>

<script>

export default {
  components: {
  },
  name: '${NAME}',
  computed: {
  },
  data() {
    return {
      titleDia:"",
      loading:false,
      formData: {
        #foreach( $ref in $CopyRule.split("%")[0].split(",") )
            $ref.split("-")[4]:"",//$ref.split("-")[0]
        #end
      },
      rules: {
        #foreach( $ref in $CopyRule.split("%")[0].split(",") )
             #if($ref.split("-")[2] == 'Y')
                $ref.split("-")[4]: [{ required: true, message: '请输入$ref.split("-")[0]', trigger: 'change' } ],// $ref.split("-")[0]
             #{else}
                $ref.split("-")[4]: [{ required: false, message: '请输入$ref.split("-")[0]', trigger: 'change' } ],// $ref.split("-")[0]
             #end
        #end
      },
      dialogFormVisible:false,
      currentPage:1,
      closeDialog:false,
      formData1:{},
      tableData:[
        {
       #foreach( $ref in $CopyRule.split("%")[1].split(",") )
            $ref.split("-")[0]:"$ref.split("-")[0]",//$ref.split("-")[1]
       #end
        }
      ]
    }
  },

  methods: {
    _s(){
      this.dialogFormVisible = false
    },
    closeWindow(){

    },
     // 终止按钮
    stopButton(row) {
      this.formData1 = row
      console.log(row);
      this.titleDia = "终止"
      this.dialogFormVisible = true
    },

    // 修改
    edit(row) {
      this.formData1 = row
      console.log(row);
      this.titleDia = "修改"
      this.dialogFormVisible = true

    },
    // 查看明细
    detail(row) {
      this.formData1 = row
      console.log(row);
      this.titleDia = "查看"
      this.dialogFormVisible = true
    },
    // 分页
    handleSizeChange(val) {

    },
    handleCurrentChange(val) {

    },
    submit() {
      this.loading = true
      this.$#refs['ruleForm'].validate((valid, err) => {
        if (valid) {
          let formTmp = this.formData
          let resTmp = {
           #foreach( $ref in $CopyRule.split("%")[0].split(",") )
            $ref.split("-")[4]:formTmp.$ref.split("-")[4],//$ref.split("-")[0]
           #end
          }
          console.log(`%c ${JSON.stringify(resTmp)}`, "color:red");
          this.loading = false
        }else{
          this.loading = false
        }
      })
    }
  }
}
</script>

<style scoped>
.tablemain {
  border: 1px solid  rgb(144, 147, 153);
  margin-top:20px;
  padding: 10px 20px;
}
.foot {
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-end;
  margin-top: 30px;
  box-sizing: border-box;
  padding-right: 30px;

}
.btn {
  box-sizing: border-box;
  padding: 8px 30px;
  font-size: 16px;
  font-weight: bold;
  letter-spacing: 2px;
  border-radius: 3px;
}
.submit {
  border: 1px solid #03297a;
  color: #03297a;
  background-color: #ffffff;
  margin-right: 20px;
}
.close {
  background-color: #ffffff;
  border: 1px solid #9a9a9a;
  color: #666;
}
</style>
