import React from 'react';
import "./index.less";

export default class ${COMPONENT_NAME} extends React.Component{
    constructor(props) {
        super(props);
        this.state = {  };
    }
    componentDidMount(){

    }
    render() {
        return (
            <div className="${Class_NAME}">
                ${COMPONENT_NAME}
            </div>
        );
    }
}